#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <pqxx/pqxx>
#include <iostream>
#include <string>
using namespace pqxx;
using namespace std;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    char * sql;

    try{
       connection C("dbname=fussball user=postgres password=postgres \
       hostaddr=127.0.0.1 port=5432");
       if (C.is_open()) {
          ui->label->setText("Datenbankverbindung erfolgreich");
       } else {
          ui->label->setText("Datenbankverbindung fehlgeschlagen");
          return;
       }

       sql = "SELECT * from spieler";


       nontransaction N(C);

       result R( N.exec( sql ));

       /* Welche Einträge angezeigt werden sollen */
       for (result::const_iterator c = R.begin(); c != R.end(); ++c) {
          cout << "spielernr = " << c[0].as<int>() << endl;
          cout << "vname = " << c[1].as<string>() << endl;
          cout << "nname = " << c[2].as<string>() << endl;
          cout << "mannschaft" << c[3].as<string>() << endl;
          cout << "gebdat" << c[4].as<string>() << endl;
       }
       cout << "erfolgreich" << endl;
       C.disconnect ();
    }catch (const std::exception &e){
       cerr << e.what() << std::endl;
       return;
    }
}
